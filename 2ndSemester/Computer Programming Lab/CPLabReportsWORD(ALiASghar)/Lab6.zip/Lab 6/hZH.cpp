#include<iostream>
using namespace std;



 main()
   {
     int No[4],large = 0 ,small = 0;
     for(int i = 0; i < 4;i++)
     {
         cout<<"Enter The "<<i<<" No :";
         cin>>No[i];

     }

         for(int i = 0;i < 4;i++)
         {
             if(large < No[i])
             {
                 large = No[i];
             }

         }
         for(int i = 0; i < 4; i++)
         {
             if(small > No[i])
             {
                 small = No[i];
             }
         }

         cout<<"The largest No is ="<<large;
         cout<<"\nThe Small No is ="<<small;
   }
