#include<iostream>
using namespace std;

#define line cout<<"\n";
struct movie{
    string title;
    int year;
};

void display(movie arrr[]){

    line
    cout<<".........Movies are......................................."<<endl;
    for(int i = 0; i < 3; i++){
        cout<<"The title of movie "<<i + 1<<" = "<<arrr[i].title<<endl;

        line
        cout<<"The release year of movie "<<i + 1<<" = "<<arrr[i].year<<endl;
        line
  }
}

main(){
    movie ar[3];

    for(int i = 0; i < 3; i++){
        cout<<"Enter the title of movie "<<i+1<<endl;
        cin>>ar[i].title;

        line
        cout<<"Enter the release year of movie "<<i+1<<endl;
        cin>>ar[i].year;
        line
    }

    line
    line

    display(ar);
}
