#include <iostream>

using namespace std;

main()
{
    system("cls");
    int num1;
    int num2;
    float num3;

    num1 = 10;
    num2 = 11;
    num3 = 12.6;

    cout<<"Integer num1 value is: "<<num1<<endl;

    cout<<"Integer num2 value is: "<<num2<<endl;

    cout<<"Float num3 value is: "<<num3<<endl;

    system("pause");
}