#include<iostream>
using namespace std;
#define l cout<<endl;

main()
 {
 	int No_1,No_2,R = 0;
 	char Op;
 	while(1)
 	{
 		cout<<"Enter No 1:";
 		cin>>No_1;
 		cout<<"\nEnter The Operator :"; 
 		cin>>Op;
 		cout<<"\nEnter No 2:";
 		cin>>No_2;
 		
 		switch(Op)
 		{
 			case '+': R = No_1 + No_2; 
  			cout<<"\n\nThe Sum is = "<<R; l
 			break;
 			case '-': R = No_1 - No_2; 
 			cout<<"\n\nThe Sub is = "<<R; l
 			break;
 			case '*': R = No_1 * No_2; 
 			cout<<"\n\nThe Product is = "<<R; l
 			break;
 			case '/': R = No_1 / No_2; 
 			cout<<"\n\nThe Quotient is = "<<R; l
 			break;
 			default : cout<<"\nINVALID OPERTOR ENTERED"; l l
		 }
	 }
 }