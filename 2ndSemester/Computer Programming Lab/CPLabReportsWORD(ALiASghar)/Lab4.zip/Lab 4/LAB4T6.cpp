#include<iostream>
using namespace std;

main()
 {
 	int N;
 	cout<<"Enter The Natural No :";
 	cin>>N;
 	for(int i = N;i >= 1;i--)
 	{
 		cout<<endl<<i<<endl;
	 }
 }