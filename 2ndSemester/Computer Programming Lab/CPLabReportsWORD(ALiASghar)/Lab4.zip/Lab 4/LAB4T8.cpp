#include<iostream>
using namespace std;

main()
{
   for(int i = 1;i <= 10;i++)
   {
   	if(i == 5)
   	{
   		cout<<"No :"<<i<<"\nMid of Loop\n";
	   }
	   else
   	cout<<"No :"<<i<<"\nSuleman Shah\n21PWCSE1983\n";
   	
	   }	
}