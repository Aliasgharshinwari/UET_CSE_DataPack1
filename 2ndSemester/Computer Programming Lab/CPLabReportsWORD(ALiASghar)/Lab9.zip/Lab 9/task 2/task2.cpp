#include<iostream>
using namespace std;

void input_Values(int* ptr){

    cout<<"Enter twelve numbers\n\n";

    for(int i = 0; i<12; i++){
        cout<<"Enter number "<<i+1<<"\n";
        cin>>*(ptr + i);
    }
}

void output_Values(int* ptr){

   for(int i = 0; i<12; i++){
        if(i==3 || i == 6 || i == 9)
            cout<<endl;
        cout<<"Value "<<i + 1<<" = "<<*(ptr + i)<<" ";
    }
}


main(){

    int numbers[12];

    int* arr_ptr;

    arr_ptr = numbers;

    input_Values(arr_ptr);
    output_Values(arr_ptr);


}
