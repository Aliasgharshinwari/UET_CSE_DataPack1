#include <iostream>
using namespace std;
main()
{	
	
	float sum=0;
	int count=0;
	
	cout<<"Enter the value for no of elements for both arrays\n";
	cin>>count;
	
	float array1[count];
	float array2[count];
	
	cout<<"Enter the values for array 1"<<endl;

	for(int i=0; i<count; i++)
	{
		cin>>array1[i];	
	}
	
	cout<<"Enter the values for array 2"<<endl;

	for(int i=0; i<count; i++)
	{
		cin>>array2[i];	
	}
	
	for(int i=0; i<count; i++)
	{
		sum = array1[i]+array2[i];
		cout<<"sum of arrays element "<<i+1<<"= "<<sum<<endl;
	}
}
