#include <iostream>
using namespace std;
main()
{	
	float Array[10];
	float sum=0;
	
	cout<<"Enter ten numbers\n";
	for(int i=0;i<=9;i++)
	{
		cin>>Array[i];
	}
	
	for(int i=0;i<=9;i++)
	{
		sum=sum+Array[i];
		
		if(i==9)
		{
			cout<<"Average value is "<<sum/10;
		}
		
	}
	
}
