#include <iostream>
using namespace std;
main()
{
	string name;
	string reg_no;
	string Array[2]={name,reg_no};
	
	cout<<"Enter your name and regestration no\n";
	for(int i=0;i<=1;i++)
		{
			cin>>Array[i];
		}
	
	cout<<endl;
	
	for(int j=0; j<=1; j++)
		{
			cout<<Array[j];
			cout<<endl;
		}	
}
