#include <iostream>
using namespace std;
main()
{	
	float temp=0;
	int count;
	cout<<"Enter the value for No of input values"<<endl;
	cin>>count;
	
	float array[count];
	
	
	for(int i=0;i<count;i++)
	{
		cout<<"Enter "<<"Value "<<i+1<<" = ";
		cin>>array[i];
	}
	

	
	for(int i=0; i<count-1; i++)
	{
		if(array[0] < array[i+1])
		{
			temp = array[0];
			array[0] = array[i+1];
			array[i+1] = temp;
		}
		
		
	}
		
		cout<<"\nMaximum Value Entered is "<<array[0];
}
