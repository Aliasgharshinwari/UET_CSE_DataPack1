#include <iostream>
using namespace std;
main()
{	
	float Array[12];
	int nextline=0;

	cout<<"Enter twelve values\n";
	
	for(int i=1; i<=12; i++)
	{
		cin>>Array[i];
	}

		for(int i=1;i<=12;i++)
		{
			cout<<"Value "<<i<<"= "<<Array[i];
			cout<<"\t";
			nextline++;		
		
			if(nextline==3)
			{
				cout<<endl;
				nextline=0;
			
			}
		
		}
}
