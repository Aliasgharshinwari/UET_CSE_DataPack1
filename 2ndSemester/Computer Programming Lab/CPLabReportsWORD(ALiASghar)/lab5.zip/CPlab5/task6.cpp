#include <iostream>
using namespace std;
main()
{	
	int count=0;
	
	cout<<"Enter value for no of array elements\n";
	cin>>count;
	
	float array[count];
	
	cout<<"Enter the values for array\n";
	
	for(int i=0; i<count; i++)
	{
		cin>>array[i];
	}
		
		cout<<" Input = ";
		
	for(int i=0; i<count; i++)
	{
		cout<<array[i]<<", ";
	}

	cout<<"\nOutput = ";
	
	for(int i=count-1; i>=0; i--)
	{
		cout<<array[i]<<", ";
	}
}

