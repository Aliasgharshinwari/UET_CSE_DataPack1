#include <iostream>
using namespace std;
main()
{	
	int count=0;
	float keynum=0;
	
	cout<<"Enter value for no of array elements\n";
	cin>>count;
	
	float array[count];
	
	cout<<"Enter the values for array elements one by one\n";
	
	for(int i=0; i<count; i++)
	{
		cin>>array[i];
	}
	
	cout<<"Enter key number\n";
	cin>>keynum;

	int i=0;
	
	while(keynum != array[i] )
	{
		i++;
		
	}
	
	cout<<"the index number of array is "<<i<<" that is array["<<i<<"]";
}
