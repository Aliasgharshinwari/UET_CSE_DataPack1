#include<iostream>
using namespace std;

int main(){

    int n;

    cout<<"Enter month no. between 1-12"<<endl;
    cin>>n;

    if(n >= 1 && n <= 7){
         (n == 2) ? (cout<<"28 Days") : (n%2 ==0 )? (cout<<"30 Days") : (cout<<"31 Days");

    }

    else if(n >= 8 && n <= 12){
        (n%2 ==0 )? (cout<<"31 Days") : (cout<<"30 Days");
    }
    else
        cout<<"Please enter a valid number"<<endl;

    return 0;
}
