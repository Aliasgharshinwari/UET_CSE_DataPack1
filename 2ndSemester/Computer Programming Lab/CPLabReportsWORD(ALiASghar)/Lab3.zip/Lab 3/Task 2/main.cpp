#include<iostream>
using namespace std;

int main(){

    int number1;

    cout<<"Enter number  ";
    cin>>number1;


    if(number1 % 2 == 0)
        cout<<"number is even";

    else
        cout<<"number is odd";

    return 0;
}
