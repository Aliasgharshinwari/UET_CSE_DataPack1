#include<iostream>
using namespace std;

int main(){

    int n;

    cout<<"Enter any number ";
    cin>>n;

    if(n%5 == 0 && n%7 == 0 && n%11 != 0){
        cout<<"\nMultiple of 5, Divisible by 7 and not divisible by 11";
    }

    else
        cout<<"\nAll three conditions do not match";
    return 0;
}
