#include<iostream>
using namespace std;

int main(){

    int a,b;

    cout<<"Enter value of number 1 ";
    cin>>a;

    cout<<"Enter value of number 2 ";
    cin>>b;

    (a > b) ? (cout<<"number 1 is greatest") : (cout<<"number 2 is greatest");

    return 0;
}
