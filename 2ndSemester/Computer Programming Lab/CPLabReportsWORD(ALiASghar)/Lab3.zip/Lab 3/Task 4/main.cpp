#include<iostream>
using namespace std;

int main(){

    int a;

    cout<<"Enter any number ";
    cin>>a;

    (a > 2) ? (cout<<"Name: Ali Asghar\nRegistraion No.:21PWCSE2059\nName: Ali Asghar\nRegistraion No.:21PWCSE2059") : (cout<<"Name: Ali Asghar\nRegistraion No.:21PWCSE2059");

    return 0;
}
