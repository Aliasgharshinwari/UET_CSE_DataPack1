#include<iostream>
using namespace std;

/*1.Print your name and registration number 10 times in C++ using recursion.
*/

void name();

main(){
    name();
}

void name(){
    static int i = 1;
    if(i <= 10){
        cout<<"Ali Asghar"<<endl;
    }
    else{
        exit(0);
    }
    i++;
    name();
}
