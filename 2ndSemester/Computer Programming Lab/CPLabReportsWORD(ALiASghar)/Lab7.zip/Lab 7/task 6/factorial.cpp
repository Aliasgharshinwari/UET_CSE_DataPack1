#include <iostream>
using namespace std;

int re(int n){

    if (n==0 || n==1){
        return 1;
        }
    else
    return n*re(n - 1);;
}

int main()
{
    int num =0;
    int fact = 1;
    cout<<"Enter number"<<endl;
    cin>>num;

    re(num);

    fact = re(num);
    cout<<"Fact ="<<fact;
    return 0;
}
