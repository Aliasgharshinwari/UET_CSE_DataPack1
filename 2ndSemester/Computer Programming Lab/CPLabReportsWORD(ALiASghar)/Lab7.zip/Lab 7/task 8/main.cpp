#include <iostream>

using namespace std;

int powerFunction(int B, int E){

    static int power = 1;

    power = power * B;
    E--;

    if(E == 0){
        return power;
    }
    else{
        powerFunction(B,E);
    }

}

int main()
{
    int b;
    int e;
    cout<<"Enter base number: ";
    cin>>b;

    cout<<"Enter the exponent of the number: ";
    cin>>e;

    cout<<"Power of "<<b<<" raised to exponent "<<e<<" = "<<powerFunction(b,e);
    return 0;
}
