#include<iostream>
using namespace std;

/*2.	Write a C++ program where you take two values from user if the user enters one or two of the values zero instead
of passing the zero values to the function let the function calculate default values if user enters values other than
zero pass them to function and calculate their sum.
*/

float add(float,float);

main(){
    float a = 0, b =0;
    cout<<"Enter a"<<endl;
    cin>>a;
    cout<<"Enter b"<<endl;
    cin>>b;

    cout<<"Sum = "<<add(a,b);
}

float add(float x,float y){

    if(x == 0 ){
        x = 1;
    }

    if(y == 0){
        y = 1;
    }

    int r = 1;
    r = x + y;
    return r;
}
