#include<iostream>
using namespace std;

/*4.Calculate the sum of odd natural numbers 1+3+5+7+�����. + n using Recursion. Take n as input from user.
*/

void sum(int);

main(){
    int N = 0;

    cout<<"Enter N";
    cin>>N;

    sum(N);

}

void sum(int n){
    static int s = 0;

    if(n >= 0){
        if(n % 2 != 0)
            s += n;

        n--;
        sum(n);
    }
    else{
        cout<<"Sum = "<<s;
        exit(0);
    }

}
